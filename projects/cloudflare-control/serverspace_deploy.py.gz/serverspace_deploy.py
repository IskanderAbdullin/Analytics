"""Owner-approved one-shot deployment of a private Serverspace read-only entrypoint.

Uses GitHub Actions Secrets for Cloudflare authentication. Never prints upstream
source, metadata, API responses, tokens or data from the Serverspace account.
Preserves the existing Worker via the Cloudflare code-only content update API.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import secrets
import sys
import time
from dataclasses import dataclass
from email import policy
from email.parser import BytesParser
from urllib.error import HTTPError, URLError
from urllib.request import HTTPRedirectHandler, Request, build_opener

TARGET = "babit-vps-bridge"
URL_BASE = "https://api.cloudflare.com/client/v4/accounts"
CANARY_PREFIX = "ss-readonly-ci-"
MARKER = "CF_SS_READONLY_ENTRYPOINT_20261123_V1"
MAX_BYTES = 4_000_000

PATCH = r'''
/* CF_SS_READONLY_ENTRYPOINT_20261123_V1: additive private RPC entrypoint. */
import { WorkerEntrypoint as _SSPrivateEntrypointBase_20261123 } from "cloudflare:workers";
const _ssResponse = (data, status=200) => new Response(JSON.stringify(data), {
  status, headers: {"content-type":"application/json", "cache-control":"no-store"}
});
const _ssSafe = (value, limit) => typeof value === "string" && value.length <= limit ? value :
  Number.isSafeInteger(value) ? String(value) : null;
export class ServerspaceReadOnlyEntrypoint extends _SSPrivateEntrypointBase_20261123 {
  async fetch(request) {
    const url = new URL(request.url);
    if (url.pathname !== "/internal/serverspace/list-servers" || url.search || url.hash ||
        request.method !== "POST" || request.body !== null)
      return _ssResponse({error:"ROUTE_DENIED"},404);
    const key = this.env.SERVERSPACE_API_KEY;
    if (typeof key !== "string" || key.length < 16)
      return _ssResponse({error:"SERVERSPACE_KEY_UNAVAILABLE"},503);
    let response;
    try {
      response = await fetch("https://api.serverspace.ru/api/v1/servers", {
        method:"GET", redirect:"manual", headers:{"X-API-KEY":key,Accept:"application/json"},
        signal:AbortSignal.timeout(9000)
      });
    } catch { return _ssResponse({error:"SERVERSPACE_UNREACHABLE"},502); }
    if (response.status === 401 || response.status === 403)
      return _ssResponse({error:"SERVERSPACE_AUTH_DENIED"},502);
    if (!response.ok || !response.headers.get("content-type")?.toLowerCase().includes("json"))
      return _ssResponse({error:"SERVERSPACE_HTTP_OR_CONTENT_ERROR"},502);
    let payload;
    try {
      const raw = await response.text();
      if (raw.length > 200000) throw Error("large");
      payload = JSON.parse(raw);
    } catch { return _ssResponse({error:"SERVERSPACE_INVALID_JSON"},502); }
    const list = payload && typeof payload === "object" ? payload.servers : null;
    if (!Array.isArray(list) || list.length > 250)
      return _ssResponse({error:"SERVERSPACE_SCHEMA_UNEXPECTED"},502);
    const safe=[];
    for(const item of list){
      if(!item || typeof item !== "object" || _ssSafe(item.id,100) === null)
        return _ssResponse({error:"SERVERSPACE_SCHEMA_UNEXPECTED"},502);
      safe.push({id:_ssSafe(item.id,100),name:_ssSafe(item.name,150),
        state:_ssSafe(item.state,50),is_power_on:typeof item.is_power_on==="boolean"?item.is_power_on:null});
    }
    return _ssResponse({servers:safe,count:safe.length});
  }
}
'''

CANARY_JS = r'''
export default {
  async fetch(request, env) {
    if (request.method !== "GET" || new URL(request.url).pathname !== "/check" ||
        request.headers.get("x-ci-probe") !== env.CI_PROBE_TOKEN)
      return new Response(null,{status:404});
    let response;
    try { response = await env.SS.fetch("http://ss.internal/internal/serverspace/list-servers",
      {method:"POST",redirect:"manual",signal:AbortSignal.timeout(12000)}); }
    catch {return Response.json({connected:false,error:"SERVICE_BINDING_FAILURE"});}
    let result;
    try {result=await response.json();}catch{return Response.json({connected:false,error:"INVALID_REPLY"});}
    const connected = response.status===200 && Array.isArray(result?.servers) &&
      Number.isInteger(result?.count) && result.servers.length === result.count;
    return Response.json({connected,
      error:connected?null:(typeof result?.error==="string" && /^[A-Z_]{1,64}$/.test(result.error)
        ? result.error:"UNKNOWN"), upstream_http_status:response.status});
  }
};
'''

class SafeError(Exception):
    pass

class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        return None


@dataclass
class Module:
    filename: str
    content_type: str
    content: bytes


def decode_worker(content_type: str, body: bytes, main_header: str | None = None):
    """Decode Cloudflare raw or multipart script without printing any contents."""
    if len(body) > MAX_BYTES:
        raise SafeError("SOURCE_TOO_LARGE")
    if "multipart/" in content_type.lower():
        packet = ("Content-Type: " + content_type + "\r\nMIME-Version: 1.0\r\n\r\n").encode() + body
        parsed = BytesParser(policy=policy.default).parsebytes(packet)
        if not parsed.is_multipart():
            raise SafeError("INVALID_MULTIPART")
        modules = []
        main = main_header or ""
        for part in parsed.iter_parts():
            name = part.get_param("name", header="content-disposition") or part.get_filename()
            raw = part.get_payload(decode=True)
            if not name or not isinstance(raw, bytes):
                raise SafeError("INVALID_MODULE_PART")
            if name == "metadata":
                try:
                    meta = json.loads(raw)
                    main = main or meta.get("main_module", "")
                except (TypeError, ValueError, AttributeError):
                    raise SafeError("INVALID_SOURCE_METADATA") from None
                continue
            if not re.fullmatch(r"[a-zA-Z0-9_./-]{1,150}", name):
                raise SafeError("INVALID_MODULE_NAME")
            modules.append(Module(name, part.get_content_type(), raw))
        if not modules:
            raise SafeError("NO_MODULES")
        if not main:
            candidates = [m.filename for m in modules if m.content_type in (
                "application/javascript+module", "text/javascript+module")]
            if len(candidates) != 1:
                raise SafeError("UNKNOWN_MAIN_MODULE")
            main = candidates[0]
        if not any(m.filename == main for m in modules):
            raise SafeError("MAIN_MODULE_NOT_FOUND")
        return modules, main
    if "javascript" not in content_type.lower():
        raise SafeError("UNEXPECTED_SOURCE_CONTENT_TYPE")
    return [Module("index.mjs", "application/javascript+module", body)], "index.mjs"


def append_patch(modules: list[Module], main: str):
    if len(modules) > 20:
        raise SafeError("TOO_MANY_MODULES")
    target = next((m for m in modules if m.filename == main), None)
    if not target:
        raise SafeError("MAIN_MODULE_NOT_FOUND")
    if "javascript" not in target.content_type:
        raise SafeError("NOT_ES_MODULE")
    try:
        source = target.content.decode("utf-8")
    except UnicodeError:
        raise SafeError("NON_UTF8_SOURCE") from None
    if MARKER in source:
        return False
    # Only additive ESM change; original default handler, DO and WSS remain intact.
    if "export" not in source or len(source) < 100:
        raise SafeError("UNEXPECTED_WORKER_MODULE")
    target.content += ("\n" + PATCH + "\n").encode("utf-8")
    return True


def encode_upload(modules: list[Module], main: str, extra_meta: dict | None = None):
    boundary = "cf-ss-" + secrets.token_hex(16)
    data = bytearray()
    metadata = {"main_module": main}
    if extra_meta:
        metadata.update(extra_meta)

    def part(name, content: bytes, ctype, filename=None):
        data.extend(("--" + boundary + "\r\n").encode())
        data.extend((f'Content-Disposition: form-data; name="{name}"' +
                     (f'; filename="{filename}"' if filename else '') + "\r\n").encode())
        data.extend((f"Content-Type: {ctype}\r\n\r\n").encode())
        data.extend(content)
        data.extend(b"\r\n")

    part("metadata", json.dumps(metadata, separators=(",", ":")).encode(), "application/json")
    for mod in modules:
        part(mod.filename, mod.content, mod.content_type, mod.filename)
    data.extend(("--" + boundary + "--\r\n").encode())
    return bytes(data), "multipart/form-data; boundary=" + boundary


class Cloudflare:
    def __init__(self):
        self.account = os.environ.get("CLOUDFLARE_ACCOUNT_ID", "")
        self.token = os.environ.get("CLOUDFLARE_API_TOKEN", "")
        if not re.fullmatch(r"[0-9a-fA-F]{32}", self.account) or len(self.token) < 16:
            raise SafeError("ANALYTICS_SECRETS_UNAVAILABLE")
        self.base = f"{URL_BASE}/{self.account}/workers/scripts/"

    def call(self, method, path, body=None, ctype="application/json", *, raw=False):
        if method not in ("GET", "PUT", "POST", "DELETE"):
            raise SafeError("METHOD_DENIED")
        req = Request(self.base + path, data=body, method=method,
                      headers={"Authorization": "Bearer " + self.token,
                               "Accept": "*/*" if raw else "application/json",
                               **({"Content-Type": ctype} if body is not None else {})})
        try:
            with build_opener(NoRedirect()).open(req, timeout=25) as response:
                content = response.read(MAX_BYTES + 1)
                response_ct = response.headers.get("Content-Type", "")
                main_part = response.headers.get("CF-Worker-Main-Module-Part", "")
                status = response.status
        except HTTPError as e:
            raise SafeError("CF_HTTP_" + str(e.code)) from None
        except (URLError, TimeoutError, OSError):
            raise SafeError("CF_TRANSPORT_FAILURE") from None
        if len(content) > MAX_BYTES:
            raise SafeError("CF_RESPONSE_TOO_LARGE")
        if not 200 <= status < 300:
            raise SafeError("CF_HTTP_" + str(status))
        if raw:
            return content, response_ct, main_part
        if not content:
            return None
        try:
            data = json.loads(content)
        except ValueError:
            raise SafeError("CF_INVALID_JSON") from None
        if data.get("success") is not True:
            # Never include provider messages; they may contain sensitive data.
            raise SafeError("CF_API_REJECTED")
        return data.get("result")


def patch_worker(cf: Cloudflare):
    body, ctype, main_part = cf.call("GET", TARGET + "/content/v2", raw=True)
    modules, main = decode_worker(ctype, body, main_part)
    original_sha = hashlib.sha256(b"".join(m.content for m in modules)).hexdigest()[:16]
    changed = append_patch(modules, main)
    if not changed:
        print(json.dumps({"stage":"patch","result":"already_installed", "old_bundle_sha16":original_sha}))
        return False
    upload, ctype = encode_upload(modules, main)
    cf.call("PUT", TARGET + "/content", upload, ctype)
    print(json.dumps({"stage":"patch","result":"updated", "old_bundle_sha16":original_sha}))
    return True


def probe_worker(cf: Cloudflare):
    # Disposable canary has one fixed method/route and no sensitive output.
    run_id = os.environ.get("GITHUB_RUN_ID", "")
    if not re.fullmatch(r"[0-9]{1,18}", run_id):
        raise SafeError("INVALID_RUN_ID")
    name = CANARY_PREFIX + run_id
    secret = secrets.token_hex(24)
    metadata = {"compatibility_date": "2026-11-23", "bindings": [
        {"type":"service", "name":"SS", "service":TARGET,
         "entrypoint":"ServerspaceReadOnlyEntrypoint"},
        {"type":"plain_text", "name":"CI_PROBE_TOKEN", "text":secret}
    ]}
    was_created = False
    try:
        upload, ctype = encode_upload([Module("probe.mjs","application/javascript+module",
                                                 CANARY_JS.encode())],"probe.mjs",metadata)
        cf.call("PUT",name,upload,ctype)
        was_created = True
        cf.call("POST", name + "/subdomain",json.dumps({"enabled":True,
                   "previews_enabled":False}).encode(),"application/json")
        subdomain = "videns42"  # verified account subdomain, not an account identifier
        url = f"https://{name}.{subdomain}.workers.dev/check"
        for i in range(5):
            req = Request(url,method="GET",headers={"X-Ci-Probe":secret})
            try:
                with build_opener(NoRedirect()).open(req,timeout=18) as res:
                    data=json.loads(res.read(6000))
                if not isinstance(data,dict):
                    raise SafeError("PROBE_INVALID_RESPONSE")
                result={"stage":"probe","connected":data.get("connected") is True,
                        "reason":data.get("error") if re.fullmatch(r"[A-Z_]{1,64}",
                                     str(data.get("error") or "")) else None}
                print(json.dumps(result))
                return result["connected"]
            except (HTTPError,URLError,TimeoutError):
                time.sleep(2)
        raise SafeError("PROBE_UNAVAILABLE")
    finally:
        if was_created:
            try:
                cf.call("DELETE",name)
                print(json.dumps({"stage":"probe_cleanup","result":"deleted"}))
            except SafeError as e:
                print(json.dumps({"stage":"probe_cleanup","result":"failed", "code":str(e)}))


def main():
    try:
        cf=Cloudflare()
        patch_worker(cf)
        ok=probe_worker(cf)
        return 0 if ok else 5
    except SafeError as e:
        print(json.dumps({"status":"blocked","code":str(e)}))
        return 4
    except Exception:
        print(json.dumps({"status":"blocked","code":"UNEXPECTED_RUNTIME_ERROR"}))
        return 4


if __name__ == "__main__":
    sys.exit(main())
